/*
 * Bittorrent Client using Qt and libtorrent.
 * Copyright (C) 2018-2025  Mike Tzou (Chocobo1)
 * Copyright (C) 2006  Christophe Dumez <chris@qbittorrent.org>
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 *
 * In addition, as a special exception, the copyright holders give permission to
 * link this program with the OpenSSL project's "OpenSSL" library (or with
 * modified versions of it that use the same license as the "OpenSSL" library),
 * and distribute the linked executables. You must obey the GNU General Public
 * License in all respects for all of the code used other than "OpenSSL".  If you
 * modify file(s), you may extend this exception to your version of the file(s),
 * but you are not obligated to do so. If you do not wish to do so, delete this
 * exception statement from your version.
 */

#pragma once

#include <QString>

#include "base/global.h"
#include "base/path.h"
#include "base/utils/version.h"

namespace Utils::ForeignApps
{
    inline const QString PYTHON_ISOLATE_MODE_FLAG = u"-I"_s;
    inline const QString PYTHON_UTF8_MODE_FLAG = u"-Xutf8=1"_s;

    struct PythonInfo
    {
        using Version = Utils::Version<3, 1>;

        bool isValid() const;
        bool isSupportedVersion() const;

        Path executablePath;
        Version version;

        inline static const Version MINIMUM_SUPPORTED_VERSION {3, 9, 0};
    };

    PythonInfo pythonInfo();
}
